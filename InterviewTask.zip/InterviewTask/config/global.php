<?php
	return [
		'sitetitle' => env('APP_NAME')
	];
?>