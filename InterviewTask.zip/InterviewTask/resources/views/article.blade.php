@include('include.head')

<div style="padding:20px 500px 00px 550px;">
	<h4>Course @if(isset($article->ctitle)) {{$article->ctitle}} @endif Articles</h4>
</div>
@if(isset($successBuy))
     <div class="alert alert-success">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         {{ $successBuy }}
     </div>
@endif
<div class="row">
	@foreach($article as $a)
	<div class="col-md-12" style="padding:40px 50px 10px 50px;">
		<div class="card">
		  <div class="card-header">
		    {{$a->title}}
		  </div>
		  <div class="card-body">
		    <blockquote class="blockquote mb-0">
		      <p>{{$a->description}}</p>
		      
		    </blockquote>
		  </div>
		</div>
	</div>
	@endforeach
</div>

@include('include.footer')
