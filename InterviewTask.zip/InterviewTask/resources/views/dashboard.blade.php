@include('include.head')
	
	<div style="padding:50px 500px 50px 550px;">
		<h4>List of Courses</h4>
	</div>
	@if(isset($errorMessage))
         <div class="alert alert-danger">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             {{ $errorMessage }}
         </div>
	@endif
	<div class="row" style="padding: 0 0 0 10px;">
		@foreach($course as $a)
			<div class="col-md-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h4 class="card-title">{{$a->title}}</h4>
				    <h6 class="card-title">Price : {{$a->price}}</h6>
				    <p class="card-text">{{ substr($a->description,0,100)}}</p>
				    <?php $checkOrder = App\Models\Order::where('course_id',$a->id)->where('user_id', Auth::user()->id)->first(); ?>
				    @if($checkOrder)
				    	<a href="{{ url('/article') }}/{{$a->id}}" class="btn btn-primary">View</a>
				    @else
				    	<a href="{{ url('/buy') }}/{{$a->id}}" class="btn btn-primary">Buy Now</a>
				    @endif
				  </div>
				</div>
			</div>
		@endforeach
	</div>

	
	
@include('include.footer')
