@extends('adminpanel.default.master')
<?php 
    $title = "Article | ".config('global.sitetitle');  
?>
@section('title', $title )
@section('content')

    <div class="top-dashboard-title">
        <div class="d-code-main listing-page-head-src">
            <div class="d-title">
                <h4><strong>Article</strong><span>|</span>{{ $data->total() }} Total</h4>
            </div>
        </div>
        <div class="action-btn listing-page-head-btn">
            <a href="{{ route('adminpanel.article.add') }}" class="btn-main">Add Article</a>
        </div>
    </div>

    <div class="dashboard-content-main add-user-main listing-page-main">
        <div class="add-user-one-main-content padding-zero">
            @if(session()->has('success'))
                <div class="success-message-box">
                    {{ session('success') }}
                </div>
            @endif
            @if($errors->any())
                <div class="error-message-box">                    
                    <p>{{$errors->first()}}</p>
                </div>
            @endif
            <div class="data-table-main">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Course</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 0; ?>
                        @foreach ($data as $d) 
                            <?php $counter++; ?>
                            <tr>
                                <td>{{ $counter }}</td>
                                <td>{{ $d->courses->title }}</td>
                                <td>{{ $d->title }}</td>
                                <td width="400px">{{ substr($d->description,0,50) }}...</td>
                                <td >
                                    <a href="{{ url('/adminpanel/editarticle/'.$d->id) }}"><span><i class="fas fa-edit"></i></span>Edit</a>
                                    <a href="javascript:void(0)" onclick="confirmDelete('Article', '{{ url('/adminpanel/deletearticle/'.$d->id) }}')"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="listing-page-main-bottom">
                <div class="listing-page-main-bottom-left">
                    {{ $data->render() }}
                </div>
                <div class="listing-page-main-bottom-right">
                    <div class="listing-page-main-bottom-right-drop-down">
                    </div>
                    <div class="listing-page-main-bottom-right-cnt">
                        <p>Showing {{ $data->firstItem() }} - {{ $data->lastItem() }} of {{ $data->total() }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection