<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Course</title>
    <link href="{{ asset('adminpanel/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('adminpanel/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('adminpanel/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('adminpanel/css/fontawesome-all.css') }}" rel="stylesheet">
    <link href="{{ asset('adminpanel/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('adminpanel/css/responsive.css') }}" rel="stylesheet">
</head>
<body>

<div id="sitemain">

    <!-- BEGIN :: LOGIN -->

    <div class="login-main">
        <div class="login-left">
        </div>
        <div class="login-right">
            <div class="login-right-desc-main" id="login">
                <div class="title">
                    <h2>Sign In</h2>
                </div>
                <?php
                    $formURL = route('adminpanel.submitlogin');
                ?>
                @if($errors->any())
                    <div class="error-message-box">                    
                        <p>{{$errors->first()}}</p>
                    </div>
                @endif
                @if(session()->has('username'))
                    <?php print_r(session()->all()); ?>
                @endif
                <form action="{{ $formURL }}" method="POST" id="logForm">
                    <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                    <div class="login-form-main">
                        <div class="login-form">
                            <input type="text" name="username" value="{{ old('username') }}" class="l-inp" placeholder="User Name">
                        </div>
                        <div class="login-form">
                            <input type="password" name="password" class="l-inp" placeholder="Password">
                        </div>
                        
                        <div class="for-pass">
                            <a href="javascript:void(0)" ></a>
                            <input type="submit" value="Login" class="submit-btn">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- END** :: LOGIN -->

</div>


<script src="{{ asset('adminpanel/js/jquery.min.js') }}"></script>
<script src="{{ asset('adminpanel/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('adminpanel/js/slick.min.js') }}"></script>
</body>
</html>