@extends('adminpanel.default.master')
<?php 
    $title = "Course | ".config('global.sitetitle');  
?>
@section('title', $title )
@section('content')

	<?php
        $label = "Create";

        $title = "";
        $description = "";
        $price = "";
        $id = "";
        $isError = false;

        $formRoute = 'adminpanel.course.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'adminpanel.course.update';
            }
            $title = $data['input']['title'];
            $description = $data['input']['description'];
            $price = $data['input']['price'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $title = $data['input'][0]->title;
                $description = $data['input'][0]->description;
                $price = $data['input'][0]->price;
                $id = $data['input'][0]->id;
                $formRoute = 'adminpanel.course.update';
            }
        }
        ?>
            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong>{{ $label }} Course</strong><span>|</span>Enter Course details and submit </h4>
                    </div>
                </div>
            </div>

            <div class="dashboard-content-main add-user-main">
            <div class="add-user-one-main-content">
                @if($errors->any())
                    <div class="error-message-box">                    
                        <p>{{$errors->first()}}</p>
                    </div>
                @endif
                @if($isError)
                    <div class="error-message-box">
                        <?php foreach($data['error']->all() as $error) {
                            echo "<p>". $error . "</p>";
                        } ?>
                    </div>
                @endif
                {{ Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data')) }}
                    {{ Form::hidden('id', $id)}}
                    <div class="user-pro-detail-main-content">
                        <div class="user-pro-detail-sub-content">
                            <div class="user-pro-detail-main-content-title">
                                <h1>Course management:</h1>
                            </div>
                            <div class="user-pro-detail-content">
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Title</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        {{ Form::text(
                                            'title', $title, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Title',
                                                'required' => true
                                            ]
                                            ) 
                                        }}
                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Price</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        {{ Form::text(
                                            'price', $price, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Price',
                                                'required' => true
                                            ]
                                            ) 
                                        }}
                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Description</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        {{ Form::textarea(
                                            'description', $description, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Description',
                                                'required' => true
                                            ]
                                            ) 
                                        }}
                                    </div>
                                </div>
                            </div>
                            <div class="next-step-btn-main">
                                {{ Form::button(
                                    'Save',
                                    [
                                        'class' => 'next-step',
                                        'type' => 'submit'
                                    ]
                                    )
                                }}
                            </div>
                        </div>
                    </div>
                {{ Form::close() }}
            </div>
        </div>

@endsection