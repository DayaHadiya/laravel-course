 @extends('adminpanel.default.master')
<?php 
    $title = "Dashboard | ".config('global.sitetitle');  
?>
@section('title', $title )
@section('content')

            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong>Dashboard</strong><!-- <span>|</span>#XRS-45670 --></h4>
                    </div>
                </div>
                <div class="action-btn">
                    <!-- <input id="datepicker" width="150" /> -->
                </div>
            </div>

            <div class="dashboard-content-main">
                <div class="dashboard-content-left-main" style="width: 100%;">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="dashboard-chart-box" style="min-height: 120px;">
                                <div class="dashboard-chart-text">
                                	<h2>{{ $data['course'] }}</h2>
                                	<h6>Total Course</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="dashboard-chart-box" style="min-height: 120px;">
                                <div class="dashboard-chart-text">
                                    <h2>{{ $data['article'] }}</h2>
                                    <h6>Total Article</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            

@endsection