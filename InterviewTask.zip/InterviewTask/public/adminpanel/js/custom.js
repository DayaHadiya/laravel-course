$(document).ready(function() {
    $('.close-sidemenu').click(function() {
        $(".sidebar-main").toggleClass('sidemenu-effect');
        $('.dashboard-right-side-main').toggleClass('d-right-effect');
        $('.top-header-main').toggleClass('d-right-effect');
    });
    $('li.child-menu').click(function() {
        $(this).find("ul.sub-menu").slideToggle();
        $(this).find(".menu-arrow").toggleClass('before');
    });
    $('#menu-icon').click(function(){
        $('.sidebar-main.mobile-view').addClass('open-menu');
    });
    $('.close-menu').click(function(){
        $('.sidebar-main.mobile-view').removeClass('open-menu');
    });

    $('#basic-text1').click(function() {
        if($('#search_form')) {
            $('#search_form').submit();
        }
    });
});

var confirmDelete = function(section, url) {
	if(confirm("Are you sure you want to delete " + section)) {
		window.location.href = url;
	}

};

