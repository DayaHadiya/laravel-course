<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
	public function login()
	{
		return view('login');
	}

	public function register()
	{
		return view('register');
	}

    public function loginsubmit(Request $request)
    {
    	try {
            $validated = $request->validate([
		        'email' => 'required',
		        'password' => 'required',
		    ]);

            if (Auth::guard('web')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))) {
                return redirect()->route('course');
            }

            return redirect()->back()->withInput()->withErrors(['Invalid email or password.']);
        } catch (RuntimeException $ex) {
            return redirect()->back()->withInput()->withErrors([$ex->getMessage()]);
        }
    }

    public function registersubmit(Request $request)
    {
        $input = $request->all();
        
        $validated = $request->validate([
	        'name' => 'required',
	        'email' => 'required|unique:users',
	        'phone' => 'required',
	        'password' => 'required',
	    ]);
    
        $input['userToken'] = md5(rand(1,999999));
        $input['password'] = bcrypt($input['password']);
        $input['name'] = $input['name'];
        $input['email'] = $input['email'];
        $input['phone'] = $input['phone'];
        
        $user = User::create($input);
        if($user->id>0) 
        {
            return redirect()->route('login')->with('success', 'User Register successfully.');
        } 
        
    }

    public function logout(Request $request) {
	  Auth::logout();
	  return redirect('/login');
	}
}
