<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Article;
use Validator;
use Illuminate\Support\Str;
use Illuminate\Pagination\Paginator;

class CourseController extends Controller
{
    private $pagination = 20;

    public function manage()
    {
        $data = Course::query()->paginate($this->pagination);
                
        return view('adminpanel.managecourse',compact('data'));
    }

    public function add()
    {
        $data =array('type'=>'add');
        return view('adminpanel.addcourse',compact('data'));
    }

    public function save(Request $request)
    {
        $input = $request->all();
        
        $validator = Validator::make( $input, $this->getRules('Add', $input), $this->messages());
        if($validator->fails())
        { 
            $data = array('type'=>'add','input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addcourse',['data'=>$data]);
            exit();
        }
        /*$input['userToken'] = md5(rand(1,999999));
        $input['password'] = bcrypt($input['password']);*/
        
        $user = Course::create($input);
        if($user->id>0) 
        {
            return redirect()->route('adminpanel.course.manage')->with('success', 'Course Created successfully.');
        } 
        else 
        {
            return redirect()->route('adminpanel.course.add')->withErrors(['Error creating record. Please try again.']);
        }
    }

    public function edit($id)
    { 
        $input = Course::where('id','=', $id)->get();
        $data = array('type'=>'Edit', 'input'=>$input);
        return view('adminpanel.addcourse', compact('data'));
    }

    public function update(Request $request)
    {
        //dd($request->all());
        
        $input = $request->all();
        $id = $input['id'];
        $validator = Validator::make( $input, $this->getRules('Edit', $input), $this->messages()); 
        
        if ($validator->fails())
        { 
            $data = array('type'=>'Edit', 'input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addcourse', compact('data'));
            exit();            
        }
        $update = array();
        
        $update["title"] = $input['title'];
        $update["price"] = $input['price'];
        $update["description"] = $input['description'];
        
        $user = Course::where('id', '=', $id)->update($update);
        return redirect()->route('adminpanel.course.manage')->with('success', 'Course Updated successfully.');
    }

    public function delete($id)
    {

        Course::where('id','=',$id)->delete();
        Article::where('course_id','=',$id)->delete();
        return redirect()->route('adminpanel.course.manage')->with('success', 'Course Deleted successfully.');
    }

    private function getRules($type, $input) {
        $return = array();
        $return['title'] = 'required';
        $return['description'] = 'required';
        $return['price'] = 'required';
        
        return $return;
    }

    private function messages()
    {
        return [
            'title.required'  => $this->getRequiredMessage('title'),         
            'description.required'  => $this->getRequiredMessage('description'),          
            'price.required'  => $this->getRequiredMessage('price')
        ];
    }

    private function getRequiredMessage($string) {
        return 'The ' . $string . ' field is required.';
    }

    private function getGreaterMessage($string, $maxchar) {
        return 'The ' . $string . ' may not be greater than ' . $maxchar . ' characters.';
    }
}
