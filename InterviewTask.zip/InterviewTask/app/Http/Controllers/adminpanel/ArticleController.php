<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Article;
use Validator;
use Illuminate\Support\Str;
use Illuminate\Pagination\Paginator;

class ArticleController extends Controller
{
    private $pagination = 20;

    public function manage()
    {
        $data = Article::query()->with('courses')->paginate($this->pagination);
        
        return view('adminpanel.managearticle',compact('data'));
    }

    public function add()
    {
        $data =array('type'=>'add');
        $course = Course::pluck('title','id')->toArray();
        return view('adminpanel.addarticle',compact('data','course'));
    }

    public function save(Request $request)
    {
        $input = $request->all();
        $course = Course::pluck('title','id')->toArray();
        $validator = Validator::make( $input, $this->getRules('Add', $input), $this->messages());
        if($validator->fails())
        { 
            $data = array('type'=>'add','input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addarticle',['data'=>$data],compact('course'));
            exit();
        }
        /*$input['userToken'] = md5(rand(1,999999));
        $input['password'] = bcrypt($input['password']);*/
        
        $user = Article::create($input);
        if($user->id>0) 
        {
            return redirect()->route('adminpanel.article.manage')->with('success', 'Article Created successfully.');
        } 
        else 
        {
            return redirect()->route('adminpanel.article.add')->withErrors(['Error creating record. Please try again.']);
        }
    }

    public function edit($id)
    { 
        $input = Article::where('id','=', $id)->get();
        $course = Course::pluck('title','id')->toArray();
        $data = array('type'=>'Edit', 'input'=>$input);
        return view('adminpanel.addarticle', compact('data','course'));
    }

    public function update(Request $request)
    {
        //dd($request->all());
        
        $input = $request->all();
        $id = $input['id'];
        $course = Course::pluck('title','id')->toArray();
        $validator = Validator::make( $input, $this->getRules('Edit', $input), $this->messages()); 
        
        if ($validator->fails())
        { 
            $data = array('type'=>'Edit', 'input'=>$input,'error'=>$validator->messages());
            return view('adminpanel.addarticle', compact('data','course'));
            exit();            
        }
        $update = array();
        
        $update["course_id"] = $input['course_id'];
        $update["title"] = $input['title'];
        $update["description"] = $input['description'];
        
        $article = Article::where('id', '=', $id)->update($update);
        return redirect()->route('adminpanel.article.manage')->with('success', 'Article Updated successfully.');
    }

    public function delete($id)
    {

        Article::where('id','=',$id)->delete();
        return redirect()->route('adminpanel.article.manage')->with('success', 'Article Deleted successfully.');
    }

    private function getRules($type, $input) {
        $return = array();
        $return['title'] = 'required';
        $return['description'] = 'required';
        $return['course_id'] = 'required';
        
        return $return;
    }

    private function messages()
    {
        return [
            'title.required'  => $this->getRequiredMessage('title'),         
            'description.required'  => $this->getRequiredMessage('description'),          
            'course.required'  => $this->getRequiredMessage('course')
        ];
    }

    private function getRequiredMessage($string) {
        return 'The ' . $string . ' field is required.';
    }

    private function getGreaterMessage($string, $maxchar) {
        return 'The ' . $string . ' may not be greater than ' . $maxchar . ' characters.';
    }
}
