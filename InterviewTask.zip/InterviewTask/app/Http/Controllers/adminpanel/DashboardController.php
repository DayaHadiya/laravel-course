<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Article;
use App\Models\Course;

class DashboardController extends Controller
{
    public function index() {
    	$data = array(
    		'course' => Course::count(),
    		'article' => Article::count(),
    	);
    	return view('adminpanel.dashboard', compact('data'));
    }
}
