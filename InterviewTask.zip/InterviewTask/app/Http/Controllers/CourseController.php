<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Order;
use App\Models\Article;
use Illuminate\Support\Facades\Auth;				

class CourseController extends Controller
{
    public function index()
    {
    	$course = Course::get();
    	return view('dashboard',compact('course'));
    }

    public function buy($cid)
    {
    	$course = Course::get();
    	
    	$input['course_id'] = $cid;
    	$input['user_id'] = Auth::user()->id;
    	Order::create($input);

    	$article = Article::select('articles.*','courses.title as ctitle')
    				->join('courses','articles.course_id','=','courses.id')
    				->where('articles.course_id',$cid)->get();

    	return view('article',compact('article'))->with('successBuy','Course Buy Successfully');
	    
    }

    public function article($cid)
    {
    	$article = Article::select('articles.*','courses.title as ctitle')
    				->join('courses','articles.course_id','=','courses.id')
    				->where('articles.course_id',$cid)->get();

    	return view('article',compact('article'));
	    
    }

}
