<?php 
    $menu = array(
                "Dashboard" => array(
                     
                    "sub" => "dashboard"
                ),
                "Static Webpages" => array(
                    
                    "sub" => array(
                        "Home" => "home",
                        "About Us" => "aboutus",
                        "Privacy Policy" => "privacypolicy"

                    )
                ),
                "Websites" => array(
                    
                    "sub" => array(
                         "Blog" => "manageblog",
                        "Gallery" => "managegallery",
                        "Newsletter" => "managenewslatter",
                        "Faq's" => "managefaq"
                    )
                ),
                 "Products" => array(
                  
                    "sub" => array(
                        "Products" => "manageproduct",
                        "View Category" => "managecategory",
                        "View Subcategory" => "managesubcategory"
                    )
                ),
                "Log out" => array(
                   
                    "sub" => "logout"
                ),
                
            );
?>
<div class="top-header-main">
                <div class="top-header-menu">
                    <div class="main-menu-icon">
                        <a href="JavaScript:;" id="menu-icon"><span></span></a>
                    </div>
                    <div class="top-menu">
                        <!-- <ul>
                            <li><a href="">Dashboard</a></li>
                            <li><a href="">Components</a></li>
                            <li><a href="">Applications</a></li>
                            <li><a href="">Custom</a></li>
                        </ul> -->
                        <ul>
                        <?php 
                        foreach($menu as $k => $v) { 
                            //print_r($v['sub']);
                            if(is_array($v['sub'])) {
                    ?>
                            <li class="child-menu">
                                <a href="javascript:void(0)">
                                    
                                    <span class="menu-text"><?php echo $k; ?></span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <?php 
                                    foreach($v['sub'] as $k1 => $v1) {
                                    ?>
                                    <li><a href="<?php echo e(url('/adminpanel/' . $v1)); ?>">- <?php echo $k1; ?></a></li>
                                    <?php } ?>
                                </ul>
                            </li>
                    <?php
                            } else {
                    ?>
                            <li>
                                <a href="<?php echo e(url('/adminpanel/' . $v['sub'])); ?>">
                                   
                                    <span class="menu-text"><?php echo $k; ?></span>
                                </a>
                            </li>
                    <?php
                            }
                            
                        } 
                    ?>
                </ul>
                    </div>
                    <div class="top-header-user">
                        <div class="username-main">
                            <a href="javascript:void(0);">Hi, 
                                <strong>
                                <?php
                                   
                                        echo Auth::user()->name;
                                        
                                
                                    
                                ?>
                                </strong>
                             </a>
                            <br>
                            <a href="">
                                
                            </a>
                        </div>
                        <div class="user-img">
                            <a href="" id="open-sign"><img src="<?php echo e(asset('adminpanel/images/u.png')); ?>"></a>
                        </div>
                        <div class="sign-out-pop">
                        	<a href="javascript:;" class="btn-main">Sign Out</a>
                        </div>
                    </div>
                </div>
            </div><?php /**PATH C:\xampp\ki-admin\resources\views/adminpanel/include/header.blade.php ENDPATH**/ ?>