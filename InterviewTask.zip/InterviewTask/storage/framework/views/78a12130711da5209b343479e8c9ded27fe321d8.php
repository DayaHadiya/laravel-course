<?php echo $__env->make('include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php 
    $title = "Register";  

	$formRoute = 'registersubmit';
?>
	<div style="padding:50px 500px 50px 550px;">
		<h4 > Register </h4>
	</div>
	<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			
			 <?php if($errors->any()): ?>
			    <div class="alert alert-danger">
			        <ul>
			            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </ul>
			    </div>
			<?php endif; ?>
			 <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

			 <?php echo csrf_field(); ?>
			 <div class="form-group">
			    <label for="exampleInputEmail1">Name</label>
			    <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Enter name" name="name">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Email address</label>
			    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Phone</label>
			    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter number" name="phone">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputPassword1">Password</label>
			    <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password">
			  </div>
			  <div class="form-group form-check">
			    <a href="<?php echo e(url('login')); ?>">Login</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	<button type="submit" class="btn btn-primary">Register</button>
			  </div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\InterviewTask\resources\views/register.blade.php ENDPATH**/ ?>