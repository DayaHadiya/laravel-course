
<?php 
    $title = "Home | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

	<?php
        $label = "Create";

        $userName = "";
        $email = "";
        $password = "";
        $gold = "";
        $star = "";
        $noOfWin = "";
        $noOfLoose = "";
        $id = "";
        $isError = false;

        $formRoute = 'adminpanel.user.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'adminpanel.user.update';
            }
            $userName = $data['input']['userName'];
            $email = $data['input']['email'];
            $password = $data['input']['password'];
            $gold = $data['input']['gold'];
            $star = $data['input']['star'];
            $noOfWin = $data['input']['noOfWin'];
            $noOfLoose = $data['input']['noOfLoose'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $userName = $data['input'][0]->userName;
                $email = $data['input'][0]->email;
                $password = $data['input'][0]->password;
                $gold = $data['input'][0]->gold;
                $star = $data['input'][0]->star;
                $noOfWin = $data['input'][0]->noOfWin;
                $noOfLoose = $data['input'][0]->noOfLoose;
                $id = $data['input'][0]->id;
                           
                
                $formRoute = 'adminpanel.user.update';
            }
        }
        ?>
            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong><?php echo e($label); ?> User</strong><span>|</span>Enter User details and submit </h4>
                    </div>
                </div>
            </div>

            <div class="dashboard-content-main add-user-main">
            <div class="add-user-one-main-content">
                <?php if($errors->any()): ?>
                    <div class="error-message-box">                    
                        <p><?php echo e($errors->first()); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($isError): ?>
                    <div class="error-message-box">
                        <?php foreach($data['error']->all() as $error) {
                            echo "<p>". $error . "</p>";
                        } ?>
                    </div>
                <?php endif; ?>
                <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

                    <?php echo e(Form::hidden('id', $id)); ?>

                    <div class="user-pro-detail-main-content">
                        <div class="user-pro-detail-sub-content">
                            <div class="user-pro-detail-main-content-title">
                                <h1>User management:</h1>
                            </div>
                            <div class="user-pro-detail-content">
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Username</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'userName', $userName, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter FirstName',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Email</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::email(
                                            'email', $email, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Email',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <?php
                                    if($label == "Create") 
                                    {
                                ?>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Password</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::password(
                                            'password',  
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Password',
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                 <?php } ?>
                                 <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Gold</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'gold', $gold, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter gold',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Star</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'star', $star, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter star',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>No of win</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'noOfWin', $noOfWin, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter no of win',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>No of loose</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'noOfLoose', $noOfLoose, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter no of loose',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="next-step-btn-main">
                                <?php echo e(Form::button(
                                    'Save',
                                    [
                                        'class' => 'next-step',
                                        'type' => 'submit'
                                    ]
                                    )); ?>

                            </div>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\Ramy\resources\views/adminpanel/adduser.blade.php ENDPATH**/ ?>