<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
<?php if(Auth::check()): ?>
<nav class="navbar" style="background-color: #e3f2fd;">
  <ul class="nav justify-content-end">
	  <li class="nav-item">
	    <a class="nav-link active" aria-current="page" href="<?php echo e(url('/course/')); ?>">Course</a>
	  </li>
</ul>
	<a class="nav-link " href="<?php echo e(url('/logout')); ?>" >Logout</a> 
<?php else: ?>
<nav class="navbar" style="background-color: #e3f2fd;">
  <ul class="nav justify-content-end">
	  <li class="nav-item">
	  </li>
</ul>
	<a class="nav-link " href="<?php echo e(url('/login')); ?>" >Login</a> 
<?php endif; ?>
</nav><?php /**PATH E:\xampp\InterviewTask\resources\views/include/head.blade.php ENDPATH**/ ?>