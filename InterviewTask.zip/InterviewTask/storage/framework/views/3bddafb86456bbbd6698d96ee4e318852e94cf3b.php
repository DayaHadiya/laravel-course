
<?php 
    $title = "Article | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

    <div class="top-dashboard-title">
        <div class="d-code-main listing-page-head-src">
            <div class="d-title">
                <h4><strong>Article</strong><span>|</span><?php echo e($data->total()); ?> Total</h4>
            </div>
        </div>
        <div class="action-btn listing-page-head-btn">
            <a href="<?php echo e(route('adminpanel.article.add')); ?>" class="btn-main">Add Article</a>
        </div>
    </div>

    <div class="dashboard-content-main add-user-main listing-page-main">
        <div class="add-user-one-main-content padding-zero">
            <?php if(session()->has('success')): ?>
                <div class="success-message-box">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="error-message-box">                    
                    <p><?php echo e($errors->first()); ?></p>
                </div>
            <?php endif; ?>
            <div class="data-table-main">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Course</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 0; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php $counter++; ?>
                            <tr>
                                <td><?php echo e($counter); ?></td>
                                <td><?php echo e($d->courses->title); ?></td>
                                <td><?php echo e($d->title); ?></td>
                                <td width="400px"><?php echo e(substr($d->description,0,50)); ?>...</td>
                                <td >
                                    <a href="<?php echo e(url('/adminpanel/editarticle/'.$d->id)); ?>"><span><i class="fas fa-edit"></i></span>Edit</a>
                                    <a href="javascript:void(0)" onclick="confirmDelete('Article', '<?php echo e(url('/adminpanel/deletearticle/'.$d->id)); ?>')"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="listing-page-main-bottom">
                <div class="listing-page-main-bottom-left">
                    <?php echo e($data->render()); ?>

                </div>
                <div class="listing-page-main-bottom-right">
                    <div class="listing-page-main-bottom-right-drop-down">
                    </div>
                    <div class="listing-page-main-bottom-right-cnt">
                        <p>Showing <?php echo e($data->firstItem()); ?> - <?php echo e($data->lastItem()); ?> of <?php echo e($data->total()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/managearticle.blade.php ENDPATH**/ ?>