    <div class="copy-main">
    <div class="left-copy">
        <p>2019 @ <a href="">Ramy</a></p>
    </div>
    <div class="right-copy">
        <ul>
            <li><a href="#">About</a></li>
            <li><a href="#">Team</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    </div>
 </div>
 
        </div>

        <!-- END** :: DASHBOARD -->

    </div>

    <div class="index-top-text-main">
        <div class="container">
            <div class="row">
                <div class="index-top-text-sub">
                    <h1></h1>
                    <p></p>
                </div>
            </div>
        </div>

    </div><?php /**PATH C:\xampp\Ramy\resources\views/adminpanel/include/footer.blade.php ENDPATH**/ ?>