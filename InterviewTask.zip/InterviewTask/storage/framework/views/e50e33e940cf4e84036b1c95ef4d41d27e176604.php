
<?php 
    $title = "Article | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

	<?php
        $label = "Create";

        $course_id = "";
        $title = "";
        $description = "";
        $id = "";
        $isError = false;

        $formRoute = 'adminpanel.article.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'adminpanel.article.update';
            }
            $course_id = $data['input']['course_id'];
            $title = $data['input']['title'];
            $description = $data['input']['description'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $course_id = $data['input'][0]->course_id;
                $title = $data['input'][0]->title;
                $description = $data['input'][0]->description;
                $id = $data['input'][0]->id;
                $formRoute = 'adminpanel.article.update';
            }
        }
        ?>
            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong><?php echo e($label); ?> Article</strong><span>|</span>Enter Article details and submit </h4>
                    </div>
                </div>
            </div>

            <div class="dashboard-content-main add-user-main">
            <div class="add-user-one-main-content">
                <?php if($errors->any()): ?>
                    <div class="error-message-box">                    
                        <p><?php echo e($errors->first()); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($isError): ?>
                    <div class="error-message-box">
                        <?php foreach($data['error']->all() as $error) {
                            echo "<p>". $error . "</p>";
                        } ?>
                    </div>
                <?php endif; ?>
                <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

                    <?php echo e(Form::hidden('id', $id)); ?>

                    <div class="user-pro-detail-main-content">
                        <div class="user-pro-detail-sub-content">
                            <div class="user-pro-detail-main-content-title">
                                <h1>Article management:</h1>
                            </div>
                            <div class="user-pro-detail-content">
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Course</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::select(
                                            'course_id', $course, $course_id,
                                            [
                                                'class' => 'form-control', 
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Title</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'title', $title, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Title',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Description</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::textarea(
                                            'description', $description, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Description',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="next-step-btn-main">
                                <?php echo e(Form::button(
                                    'Save',
                                    [
                                        'class' => 'next-step',
                                        'type' => 'submit'
                                    ]
                                    )); ?>

                            </div>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/addarticle.blade.php ENDPATH**/ ?>