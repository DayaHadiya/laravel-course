<div class="copy-main">
                <div class="left-copy">
                    <p>2019 @ <a href="">Keshavinfotech</a></p>
                </div>
                <div class="right-copy">
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div><?php /**PATH D:\xampp\htdocs\JOLE\resources\views/adminpanel/include/footer.blade.php ENDPATH**/ ?>