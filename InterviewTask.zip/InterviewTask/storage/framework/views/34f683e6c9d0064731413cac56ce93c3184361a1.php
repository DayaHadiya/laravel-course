<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Course</title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
</head>
<body>

<div id="sitemain">

    <!-- BEGIN :: LOGIN -->

    <div class="login-main">
        <div class="login-left">
        </div>
        <div class="login-right">
            <div class="login-right-desc-main" id="login">
                <div class="title">
                    <h2>Sign In</h2>
                </div>
                <?php
                    $formURL = route('adminpanel.submitlogin');
                ?>
                <?php if($errors->any()): ?>
                    <div class="error-message-box">                    
                        <p><?php echo e($errors->first()); ?></p>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('username')): ?>
                    <?php print_r(session()->all()); ?>
                <?php endif; ?>
                <form action="<?php echo e($formURL); ?>" method="POST" id="logForm">
                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                    <div class="login-form-main">
                        <div class="login-form">
                            <input type="text" name="username" value="<?php echo e(old('username')); ?>" class="l-inp" placeholder="User Name">
                        </div>
                        <div class="login-form">
                            <input type="password" name="password" class="l-inp" placeholder="Password">
                        </div>
                        
                        <div class="for-pass">
                            <a href="javascript:void(0)" ></a>
                            <input type="submit" value="Login" class="submit-btn">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- END** :: LOGIN -->

</div>


<script src="<?php echo e(asset('adminpanel/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminpanel/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminpanel/js/slick.min.js')); ?>"></script>
</body>
</html><?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/login.blade.php ENDPATH**/ ?>