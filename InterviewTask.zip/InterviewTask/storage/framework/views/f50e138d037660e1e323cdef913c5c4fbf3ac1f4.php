<?php echo $__env->make('include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding:20px 500px 00px 550px;">
	<h4>Course <?php if(isset($article->ctitle)): ?> <?php echo e($article->ctitle); ?> <?php endif; ?> Articles</h4>
</div>
<?php if(isset($successBuy)): ?>
     <div class="alert alert-success">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         <?php echo e($successBuy); ?>

     </div>
<?php endif; ?>
<div class="row">
	<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-12" style="padding:40px 50px 10px 50px;">
		<div class="card">
		  <div class="card-header">
		    <?php echo e($a->title); ?>

		  </div>
		  <div class="card-body">
		    <blockquote class="blockquote mb-0">
		      <p><?php echo e($a->description); ?></p>
		      
		    </blockquote>
		  </div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\InterviewTask\resources\views/article.blade.php ENDPATH**/ ?>