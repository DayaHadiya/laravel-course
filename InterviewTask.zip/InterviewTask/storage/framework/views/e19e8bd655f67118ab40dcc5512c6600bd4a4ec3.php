
<?php 
    $title = "Home | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

                <?php
               
                $isError = false;
                $formRoute = 'adminpanel.home.edit';
                if(isset($data['error'])) {
                    $isError = true;
                    if($data['type']=="Edit") {
                        $label = "Edit";
                        $formRoute = 'adminpanel.home.update';
                    }
                    $pageheader = $data['input']['pageheader'];
                    $title = $data['input']['title'];
                    $keywords = $data['input']['keywords'];
                    $description = $data['input']['description'];
                    $content = $data['input']['content'];
                    $image = $data['input']['image'];
                } else { 
                    if($data['type'] == "edit") {
                        $label = "Edit";
                        $pageheader = $data['input'][0]->pageheader;
                        $title = $data['input'][0]->title;
                        $keywords = $data['input'][0]->keywords;
                        $description = $data['input'][0]->description;
                        $content = $data['input'][0]->content;
                        $image = $data['input'][0]->image;
                        $id = $data['input'][0]->id;
                        $formRoute = 'adminpanel.home.update';
                    }
                } 
                ?>
                <div class="top-dashboard-title">
                    <div class="d-code-main">
                        <div class="d-title">
                            <h4><strong>
                            Static Page Management
                            </strong><span>|</span></h4>
                        </div>
                    </div>
                    <!-- <div class="action-btn">
                        <a href="#" class="btn-main">Actions<span><img src="images/b.png"></span></a>
                    </div> -->
                </div>

                <div class="dashboard-content-main add-user-main">
                    <div class="add-user-one-main-content">
                        <!-- <div class="add-user-one-main-content-top">
                            <div class="add-user-one-main-content-top-left">
                                <h1>1</h1>
                            </div>
                            <div class="add-user-one-main-content-top-right">
                                <h1>Profile</h1>
                                <p>User’s Personal Information</p>
                            </div>
                        </div> -->
                        <?php if($errors->any()): ?>
                            <div class="error-message-box">                    
                                <p><?php echo e($errors->first()); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if($isError): ?>
                            <div class="error-message-box">
                                <?php foreach($data['error']->all() as $error) {
                                    echo "<p>". $error . "</p>";
                                } ?>
                            </div>
                        <?php endif; ?>
                        <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

                            <?php echo e(Form::hidden(
                                'pageheader', $pageheader
                                )); ?>

                            <div class="user-pro-detail-main-content">
                                <div class="user-pro-detail-sub-content">
                                    <div class="user-pro-detail-content">
                                        <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Page Header</label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                <?php echo e(Form::text(
                                                    'pageheader', $pageheader, 
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Enter firstname',
                                                        'required' => false
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                        <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Browser Bar Title</label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                <?php echo e(Form::text(
                                                    'title', $title, 
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Enter lastname',
                                                        'required' => false
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                        <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Meta Keywords</label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                <?php echo e(Form::text(
                                                    'keywords', $keywords, 
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Enter phone no.',
                                                        'required' => false
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                        <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Meta Description </label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                <?php echo e(Form::textarea(
                                                    'description', $description, 
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Enter phone no.',
                                                        'required' => false
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                         <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Manage Primary Image/Flash</label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                 <?php echo e(Form::file(
                                                    'image',
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Select Image',
                                                        'required' => false,
                                                        'id'=> 'profilePicture'
                                                    ]
                                                )); ?>

                                            </div>
                                        </div>
                                             <div class="user-pro-detail-content-dt-one">
                                            <div class="user-pro-detail-content-left">
                                                <label>Page Content</label>
                                            </div>
                                            <div class="user-pro-detail-content-right">
                                                <?php echo e(Form::textarea(
                                                    'content', $content, 
                                                    [
                                                        'class' => 'form-control', 
                                                        'placeholder' => 'Enter phone no.',
                                                        'required' => false
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                    
                                    </div>
                                    <div class="next-step-btn-main">
                                        <?php echo e(Form::button(
                                            'Edit',
                                            [
                                                'class' => 'next-step',
                                                'type' => 'submit'
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>

                

<?php $__env->stopSection(); ?>        

    
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pratapsingh\resources\views/adminpanel/home.blade.php ENDPATH**/ ?>