
<div class="top-header-main">
    <div class="top-header-menu">
        <div class="main-menu-icon">
            <a href="JavaScript:;" id="menu-icon"><span></span></a>
        </div>
        <div class="top-menu">
        </div>
        <div class="top-header-user">
            <div class="username-main">
                <a href="javascript:void(0);">Hi, 
                    <strong>
                    <?php echo Auth::user()->name; ?>
                    </strong>
                 </a>
                <br>
                <a href="">
                    
                </a>
            </div>
            <div class="user-img">
                <a href="" id="open-sign"><img src="<?php echo e(asset('adminpanel/images/u.png')); ?>"></a>
            </div>
            <div class="sign-out-pop">
            	<a href="javascript:;" class="btn-main">Sign Out</a>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/include/header.blade.php ENDPATH**/ ?>