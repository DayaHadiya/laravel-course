<?php 
    $menu = array(
                "DASHBOARD" => array(
                    "icon" => "home.png", 
                    "sub" => "dashboard"
                ),
                "Course" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage course" => "managecourse",
                        "Add course" => "addcourse",
                    )
                ), 
                 "Article" => array(
                    "icon" => "user.png", 
                    "sub" => array(
                        "Manage Article" => "managearticle",
                        "Add Article" => "addarticle",
                    )
                ),
                "Log out" => array(
                    "icon" => "home.png", 
                    "sub" => "logout"
                ),
            );
?>

<div class="sidebar-main desktop-view">
	<div class="top-logo-main">
		<h5 style="color:#fff;">Welcome Admin</h5>
		<a href="javascript:;" class="close-sidemenu"><img src="<?php echo e(asset('adminpanel/images/side.png')); ?>"></a>
	</div>

	<div class="sidebar-menu-main">
		<ul>
            <?php 
                foreach($menu as $k => $v) { 
                    //print_r($v['sub']);
                    if(is_array($v['sub'])) {
            ?>
                    <li class="child-menu">
                        <a href="javascript:void(0)">
                            <span class="m-icon"><img src="<?php echo e(asset('adminpanel/images/' . $v['icon'])); ?>"></span>
                            <span class="menu-text"><?php echo $k; ?></span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <?php 
                            foreach($v['sub'] as $k1 => $v1) {
                            ?>
                            <li><a href="<?php echo e(url('/adminpanel/' . $v1)); ?>">- <?php echo $k1; ?></a></li>
                            <?php } ?>
                        </ul>
                    </li>
            <?php
                    } else {
            ?>
                    <li>
                        <a href="<?php echo e(url('/adminpanel/' . $v['sub'])); ?>">
                            <span class="m-icon"><img src="<?php echo e(asset('adminpanel/images/' . $v['icon'])); ?>"></span>
                            <span class="menu-text"><?php echo $k; ?></span>
                        </a>
                    </li>
            <?php
                    }
                    
                }
            ?>
		</ul>
	</div>
</div>

<?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/include/sidebar.blade.php ENDPATH**/ ?>