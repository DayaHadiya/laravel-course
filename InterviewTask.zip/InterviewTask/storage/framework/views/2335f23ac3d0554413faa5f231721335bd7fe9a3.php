 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/highcharts.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/gijgo.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/tagsinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" media="screen">
    
</head>
<body>

    <div id="sitemain">

        <!-- BEGIN :: DASHBOARD -->

        <div class="dashboard-main" id="dashboard">
        <?php echo $__env->make('adminpanel.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-right-side-main">
        <?php echo $__env->make('adminpanel.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('adminpanel.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('adminpanel/js/jquery.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/bootstrap-multiselectsplitter.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-touchspin/4.2.5/jquery.bootstrap-touchspin.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/gijgo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/tagsinput.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/file-upload.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/custom.js')); ?>"></script>

    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });

        $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4'
        });

        // $('.datepicker1').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        // $('#datepicker2').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        // $('#datepicker3').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        $('#startDate').datepicker({
            uiLibrary: 'bootstrap4'
        });
        $('#endDate').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

    <script>
        $('#datetimepicker1').datetimepicker({

        });
    </script>
</body>

</html><?php /**PATH E:\xampp\InterviewTask\resources\views/adminpanel/default/master.blade.php ENDPATH**/ ?>