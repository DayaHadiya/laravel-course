<?php echo $__env->make('include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<div style="padding:50px 500px 50px 550px;">
		<h4>List of Courses</h4>
	</div>
	<?php if(isset($errorMessage)): ?>
         <div class="alert alert-danger">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <?php echo e($errorMessage); ?>

         </div>
	<?php endif; ?>
	<div class="row" style="padding: 0 0 0 10px;">
		<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h4 class="card-title"><?php echo e($a->title); ?></h4>
				    <h6 class="card-title">Price : <?php echo e($a->price); ?></h6>
				    <p class="card-text"><?php echo e(substr($a->description,0,100)); ?></p>
				    <?php $checkOrder = App\Models\Order::where('course_id',$a->id)->where('user_id', Auth::user()->id)->first(); ?>
				    <?php if($checkOrder): ?>
				    	<a href="<?php echo e(url('/article')); ?>/<?php echo e($a->id); ?>" class="btn btn-primary">View</a>
				    <?php else: ?>
				    	<a href="<?php echo e(url('/buy')); ?>/<?php echo e($a->id); ?>" class="btn btn-primary">Buy Now</a>
				    <?php endif; ?>
				  </div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	
	
<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\InterviewTask\resources\views/dashboard.blade.php ENDPATH**/ ?>