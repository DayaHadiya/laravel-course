
<?php 
    $title = "Home | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

	<?php
        $label = "Create";

        $email = "";
        $password = "";
        $firstname = "";
        $lastname = "";
        $gender = "";
        $birthdate = "";
        $contactNo = "";
        $image = "";
        $userType = "";
        $id = "";
        $isError = false;

        $formRoute = 'adminpanel.user.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'adminpanel.user.update';
            }
            $email = $data['input']['email'];
            //$password = $data['input']['password'];
            $firstname = $data['input']['firstname'];
            $lastname = $data['input']['lastname'];
            $gender = $data['input']['gender'];
            $birthdate = $data['input']['birthdate'];
            $contactNo = $data['input']['contactNo'];
            //$image = $data['input']['image'];
            $userType = $data['input']['userType'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $email = $data['input'][0]->email;
                //$password = $data['input'][0]->password;
                $firstname = $data['input'][0]->firstname;
                $lastname = $data['input'][0]->lastname;
                $gender = $data['input'][0]->gender;
                $birthdate = $data['input'][0]->birthdate;
                $contactNo = $data['input'][0]->contactNo;
                $image = $data['input'][0]->image;
                $userType = $data['input'][0]->userType;
                $id = $data['input'][0]->id;
                           
                if($image!="" && $image!=null)
                {
                    if(file_exists(public_path()."/uploads/user_image/".$image))
                    {
                        $clogo = asset('/uploads/user_image/'.$image);
                    }
                }

                $formRoute = 'adminpanel.user.update';
            }
        }
        ?>
            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong><?php echo e($label); ?> User</strong><span>|</span>Enter User details and submit </h4>
                    </div>
                </div>
            </div>

            <div class="dashboard-content-main add-user-main">
            <div class="add-user-one-main-content">
                <?php if($errors->any()): ?>
                    <div class="error-message-box">                    
                        <p><?php echo e($errors->first()); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($isError): ?>
                    <div class="error-message-box">
                        <?php foreach($data['error']->all() as $error) {
                            echo "<p>". $error . "</p>";
                        } ?>
                    </div>
                <?php endif; ?>
                <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

                    <?php echo e(Form::hidden('id', $id)); ?>

                    <div class="user-pro-detail-main-content">
                        <div class="user-pro-detail-sub-content">
                            <div class="user-pro-detail-main-content-title">
                                <h1>User management:</h1>
                            </div>
                            <div class="user-pro-detail-content">
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Image</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <div class="user-img-main" style="display: flex; flex-direction: row; align-items: center; justify-content: center;">
                                            <img src="<?php echo e($clogo); ?>" id="logoimg" style="max-width: 100%; max-height: 100%; width: auto; height: auto;">
                                            <div class="button-wrapper">
                                                <span class="label">
                                                    <img src="<?php echo e(asset('adminpanel/images/pencil-edit-button.svg')); ?>">
                                                </span>
                                                <?php echo e(Form::file(
                                                    'image', 
                                                    [
                                                        'class' => 'upload-box',
                                                        'id' => 'image',
                                                        'placeholder' => 'Select Profile Image',
                                                        'onchange' => 'displaySingleImagePreview(this, "logoimg")'
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Firstname</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'firstname', $firstname, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter FirstName',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Lastname</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'lastname', $lastname, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter LastName',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>gender</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::radio(
                                            'gender', "male", 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter gender',
                                                'required' => true
                                            ]
                                            )); ?> Male &nbsp; &nbsp;
                                        <?php echo e(Form::radio(
                                            'gender', "female", 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter gender',
                                                'required' => true
                                            ]
                                            )); ?> Female
                                    </div>
                                </div> 
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Email</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::email(
                                            'email', $email, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Email',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <?php
                                    if($label == "Create") 
                                    {
                                ?>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Password</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::password(
                                            'password',  
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Password',
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                 <?php } ?>
                                 <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Birthdate</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::date(
                                            'birthdate', $birthdate, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter birthdate',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Contact no.</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::number(
                                            'contactNo', $contactNo, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Contact no.',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>User Type</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::radio(
                                            'userType', "parent", 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter user type',
                                                'required' => true
                                            ]
                                            )); ?> Parent &nbsp; &nbsp;
                                        <?php echo e(Form::radio(
                                            'userType', "adult", 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter user type',
                                                'required' => true
                                            ]
                                            )); ?> Adult
                                    </div>
                                </div> 
                            </div>
                            <div class="next-step-btn-main">
                                <?php echo e(Form::button(
                                    'Save',
                                    [
                                        'class' => 'next-step',
                                        'type' => 'submit'
                                    ]
                                    )); ?>

                            </div>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\Jannet new\resources\views/adminpanel/adduser.blade.php ENDPATH**/ ?>