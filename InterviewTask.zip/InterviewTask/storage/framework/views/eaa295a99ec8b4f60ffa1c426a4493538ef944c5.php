<div class="top-header-main">
                <div class="top-header-menu">
                    <div class="main-menu-icon">
                        <a href="JavaScript:;" id="menu-icon"><span></span></a>
                    </div>
                    <div class="top-menu">
                        <!-- <ul>
                            <li><a href="">Dashboard</a></li>
                            <li><a href="">Components</a></li>
                            <li><a href="">Applications</a></li>
                            <li><a href="">Custom</a></li>
                        </ul> -->
                    </div>
                    <div class="top-header-user">
                        <div class="username-main">
                            <a href="javascript:void(0);">Hi, 
                                <strong>
                                <?php
                                    if(session('adminid') > 0){
                                        echo $value = session('username');
                                    }
                                    
                                ?>
                                </strong>
                            </a>
                            <br>
                            <a href="javascript:void(0);">
                                <?php
                                    if(session('adminid') > 0){
                                        echo "Logout";
                                    }
                                ?>
                            </a>
                        </div>
                        <div class="user-img">
                            <a href="javascript:;" id="open-sign"><img src="<?php echo e(asset('adminpanel/images/u.png')); ?>"></a>
                        </div>
                        <div class="sign-out-pop">
                        	<a href="javascript:;" class="btn-main">Sign Out</a>
                        </div>
                    </div>
                </div>
            </div><?php /**PATH D:\xampp\htdocs\JOLE\resources\views/adminpanel/include/header.blade.php ENDPATH**/ ?>