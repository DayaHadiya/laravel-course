<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KI Admin</title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/highcharts.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/gijgo.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/tagsinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" media="screen">
    
</head>
<body>

    <div id="sitemain">

        <!-- BEGIN :: DASHBOARD -->

        <div class="dashboard-main" id="dashboard"><?php /**PATH C:\xampp\pratapsingh\resources\views/adminpanel/include/head.blade.php ENDPATH**/ ?>