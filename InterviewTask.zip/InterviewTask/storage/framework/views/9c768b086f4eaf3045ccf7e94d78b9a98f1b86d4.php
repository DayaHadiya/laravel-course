 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pratapsingh</title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/highcharts.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/gijgo.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/tagsinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" media="screen">
    
</head>
<body>

    <div id="sitemain">

        <!-- BEGIN :: DASHBOARD -->

        <div class="dashboard-main" id="dashboard">
        <?php echo $__env->make('adminpanel.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-right-side-main">
        <?php echo $__env->make('adminpanel.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('adminpanel.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('adminpanel/js/jquery.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/bootstrap-multiselectsplitter.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-touchspin/4.2.5/jquery.bootstrap-touchspin.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
    <script src="<?php echo e(asset('adminpanel/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/gijgo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/tagsinput.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/file-upload.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/custom.js')); ?>"></script>

    <script>
        CKEDITOR.replace( 'description' );
    </script>

    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });

        $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4'
        });

        // $('.datepicker1').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        // $('#datepicker2').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        // $('#datepicker3').datepicker({
        //     uiLibrary: 'bootstrap4'
        // });

        $('#startDate').datepicker({
            uiLibrary: 'bootstrap4'
        });
        $('#endDate').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

    <script>
        $('#datetimepicker1').datetimepicker({

        });
    </script>
    <script>
        $(".dropdown-menu li a").click(function(){
          var selText = $(this).text();
          $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
        });

        $("#addChild").click(function() {
            var child_counter = $("#child_counter");
            var child_counter_val = child_counter.val();
            child_counter_val = parseInt(child_counter_val)+parseInt(1);
            child_counter.val(child_counter_val);
            var childContainer = $("#childContainer");
            var childForm = '<div class="user-pro-detail-content-dt-one" id="cfnameContainer'+child_counter_val+'"><div style="position: absolute; right: 25px; cursor: pointer;"><img onclick="funRemoveChild('+child_counter_val+')" title="Remove child" alt="Remove child" src="<?php echo e(asset('/adminpanel/images/close-circle-outline.png')); ?>" width="25" height="25" ></div><div class="user-pro-detail-content-left"><label>Enter child firstname</label></div><div class="user-pro-detail-content-right"><input type="text" name="cfname'+child_counter_val+'" class="form-control" placeholder="Enter child firstname" ></div></div>';
            childForm += '<div class="user-pro-detail-content-dt-one" id="clnameContainer'+child_counter_val+'"><div class="user-pro-detail-content-left"><label>Enter child lastname</label></div><div class="user-pro-detail-content-right"><input type="text" name="clname'+child_counter_val+'" class="form-control" placeholder="Enter child lastname" ></div></div>';
            childForm += '<div class="user-pro-detail-content-dt-one" id="cgenderContainer'+child_counter_val+'"><div class="user-pro-detail-content-left"><label>Select child gender</label></div><div class="user-pro-detail-content-right"><label class="ki-radio ki-radio-bold ki-radio-brand"><input checked="checked" name="cgender'+child_counter_val+'" type="radio" value="M"> Male<span></span></label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <label class="ki-radio ki-radio-bold ki-radio-brand"><input name="cgender1" type="radio" value="F"> Female<span></span></label></div></div>';
            childForm += '<div class="user-pro-detail-content-dt-one" id="cbdateContainer'+child_counter_val+'"><div class="user-pro-detail-content-left"><label>Select child birthdate</label></div><div class="user-pro-detail-content-right"><input class="form-control" id="datepicker'+child_counter_val+'" placeholder="Select child birthdate" name="cbdate'+child_counter_val+'" type="text" value="" ></div></div>';
            childForm += '<div class="user-pro-detail-content-dt-one" id="chrContainer'+child_counter_val+'" style="padding-bottom: 0;"><hr style="width: 90%;"></div>';
            childForm += '<script id="scriptContainer'+child_counter_val+'">$("#datepicker'+child_counter_val+'").datepicker({uiLibrary: "bootstrap4"});<\/script>';
            childContainer.append(childForm);
        });

        var funRemoveChild = function(id) {
            console.log("ID: " + id);
            $("#cfnameContainer"+id).remove();
            $("#clnameContainer"+id).remove();
            $("#cgenderContainer"+id).remove();
            $("#cbdateContainer"+id).remove();
            $("#chrContainer"+id).remove();
            $("#scriptContainer"+id).remove();
        }
    </script>

</body>

</html><?php /**PATH C:\xampp\pratapsingh\resources\views/adminpanel/default/master.blade.php ENDPATH**/ ?>