<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('global.sitetitle')); ?> Adminpanel</title>
    <link href="<?php echo e(asset('adminpanel/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/highcharts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/gijgo.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminpanel/css/responsive.css')); ?>" rel="stylesheet">
</head>
<body>

<div id="sitemain">

    <!-- BEGIN :: DASHBOARD -->

    <div class="dashboard-main" id="dashboard">

    	<?php echo $__env->make('adminpanel.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="dashboard-right-side-main">

            <?php echo $__env->make('adminpanel.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong>Dashboard</strong><!-- <span>|</span>#XRS-45670 --></h4>
                    </div>
                </div>
                <div class="action-btn">
                    <!-- <input id="datepicker" width="150" /> -->
                </div>
            </div>

            <div class="dashboard-content-main">
                <div class="dashboard-content-left-main" style="width: 100%;">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="dashboard-chart-box" style="min-height: 120px;">
                                <div class="dashboard-chart-text">
                                	<h2><?php echo e($data['customer']); ?></h2>
                                	<h6>Total Customer</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            

        </div>

    </div>

    <!-- END** :: DASHBOARD -->

</div>


<script src="<?php echo e(asset('adminpanel/js/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="<?php echo e(asset('adminpanel/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminpanel/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminpanel/js/highcharts.js')); ?>"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="<?php echo e(asset('adminpanel/js/gijgo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminpanel/js/custom.js')); ?>"></script>

<script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

<script>
Highcharts.chart('container', {

    chart: {
        type: 'spline',
        inverted: false
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
  
   		lineWidth: 0,
   		minorGridLineWidth: 0,
   		visible: false,
   		lineColor: 'transparent',
  
   		labels: {
       		enabled: false
   		},
   		minorTickLength: 0,
   		tickLength: 0
	},
    yAxis: {
    	
        labels: {
            enabled: false
        },
        title: {
            text: null
        },
        reversed: true,
        visible: false
    },
    legend: {
        enabled: false
    },
    
    
    series: [{
        name: '',
        color: '#5d78ff',
        data: [[0, 15], [10, -50],
            [50, -2.5], [60, -27.7]]
    }]
});


// -------------------------------------------------------

Highcharts.chart('container1', {

    chart: {
        type: 'spline',
        inverted: false
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
  
   		lineWidth: 0,
   		minorGridLineWidth: 0,
   		visible: false,
   		lineColor: 'transparent',
  
   		labels: {
       		enabled: false
   		},
   		minorTickLength: 0,
   		tickLength: 0
	},
    yAxis: {
    	
        labels: {
            enabled: false
        },
        title: {
            text: null
        },
        reversed: true,
        visible: false
    },
    legend: {
        enabled: false
    },
    
    
    series: [{
        name: '',
        color: '#71d2bf',
        data: [[0, 30], [15, 10],
            [50, -2.5], [60, -27.7]]
    }]
});

// -------------------------------------------------------

Highcharts.chart('container2', {

    chart: {
        type: 'spline',
        inverted: false
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
  
   		lineWidth: 0,
   		minorGridLineWidth: 0,
   		visible: false,
   		lineColor: 'transparent',
  
   		labels: {
       		enabled: false
   		},
   		minorTickLength: 0,
   		tickLength: 0
	},
    yAxis: {
    	
        labels: {
            enabled: false
        },
        title: {
            text: null
        },
        reversed: true,
        visible: false
    },
    legend: {
        enabled: false
    },
    
    
    series: [{
        name: '',
        color: '#fd3995',
        data: [[0, 50], [20, -40],
            [30, -5.5], [90, -10.7]]
    }]
});

// -------------------------------------------------------

Highcharts.chart('container3', {

    chart: {
        type: 'spline',
        inverted: false
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
  
   		lineWidth: 0,
   		minorGridLineWidth: 0,
   		visible: false,
   		lineColor: 'transparent',
  
   		labels: {
       		enabled: false
   		},
   		minorTickLength: 0,
   		tickLength: 0
	},
    yAxis: {
    	
        labels: {
            enabled: false
        },
        title: {
            text: null
        },
        reversed: true,
        visible: false
    },
    legend: {
        enabled: false
    },
    
    
    series: [{
        name: '',
        color: '#607aff',
        data: [[0, -10], [20, -50],
            [30, -2.5], [60, -27.7]]
    }]
});

// ----------------------------------------------

Highcharts.chart('container4', {
    chart: {
        type: 'areaspline',
        style: {
            fontFamily: 'Poppins',
            color: "#646c9a"
        }
    },
    title: {
        text: ''
    },
    legend: {
        enabled: false,
    },
    xAxis: {
    	style: {
            fontFamily: 'Poppins',
            color: "#646c9a"
        },
    	gridLineDashStyle: 'longdash',
        categories: [
            '1 Jan',
            '2 Jan',
            '3 Jan',
            '4 Jan',
            '5 Jan',
            '6 Jan',
            '7 Jan'
        ],
        
    },
    yAxis: {
    	style: {
            fontFamily: 'Poppins',
            color: "#646c9a"
        },
    	gridLineDashStyle: 'longdash',
    	color: '#afb4d4',
        title: {
            text: ''
        }
    },
    tooltip: {
        shared: true,
        valueSuffix: ' '
    },
    credits: {
        enabled: false
    },
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            enableMouseTracking: false
        }
    },
    series: [{
    	color: '#bec7fc',
    	style: {
            fontFamily: 'Poppins',
            color: "#646c9a"
        },
        name: '',
        data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2]
    }, {
    	color: '#92a4ff',
    	style: {
            fontFamily: 'Poppins',
            color: "#646c9a"
        },
        name: '',
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0]
    }],
    responsive: {
        rules: [{
            condition: {
                
            },
            chartOptions: {
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom'
                }
            }
        }]
    }
});

</script>


</body>
</html><?php /**PATH C:\xampp\Admin-lara-8\resources\views/adminpanel/dashboard.blade.php ENDPATH**/ ?>