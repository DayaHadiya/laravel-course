
<?php 
    $title = "Home | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

    <div class="top-dashboard-title">
        <div class="d-code-main listing-page-head-src">
            <div class="d-title">
                <h4><strong>User</strong><span>|</span><?php echo e($data->total()); ?> Total</h4>
                <div class="input-group md-form form-sm form-2 pl-0">
                   <form method="get" action="<?php echo e(route('adminpanel.user.search')); ?>" enctype="multipart/form-data" style="display: flex;" id="search_form">
                        <input class="form-control my-0 py-1" type="text" name="search" placeholder="Search..." aria-label="Search">
                        <div class="input-group-append">
                            <span class="input-group-text lighten-3" id="basic-text1"><i class="fas fa-search text-grey"
                                aria-hidden="true"></i></span>
                        </div>
                    </form>  
                </div>
                <div class="filter-range-picker">
                    <!-- <div class="user-pro-detail-content-right com-input">
                        <div class="daterange">
                            <input id="startDate" type="text" class="form-control" name="start" placeholder="Start Date">
                            <input id="endDate" type="text" class="form-control" name="end" placeholder="End Date">
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="action-btn listing-page-head-btn">
            <a href="<?php echo e(route('adminpanel.user.add')); ?>" class="btn-main">Add User</a>
        </div>
    </div>

    <div class="dashboard-content-main add-user-main listing-page-main">
        <div class="add-user-one-main-content padding-zero">
            <?php if(session()->has('success')): ?>
                <div class="success-message-box">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="error-message-box">                    
                    <p><?php echo e($errors->first()); ?></p>
                </div>
            <?php endif; ?>
            <div class="data-table-main">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <!-- <th id="th-check">
                                <label class="custom-check-label">
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                </label>
                            </th> -->
                            <th>Image</th>
                            <th>Firstname</th>
                            <th>Lastname</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 0; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php $counter++; ?>
                            <tr>
                                <td><?php echo e($counter); ?>

                                </td>
                                <!-- <td id="td-check">
                                    <label class="custom-check-label">
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                    </label>
                                </td> -->
                                <td><img src="<?php echo e(asset('/uploads/user_image')); ?>/<?php echo e($d->image); ?>" style="width: 60px; height: 60px;"></img> </td>
                                <td><?php echo e($d->firstname); ?></td>
                                <td><?php echo e($d->lastname); ?></td>
                                <td><?php echo e($d->email); ?></td>
                                <td><?php echo e($d->gender); ?></td>
                                <td class="dropdown-td">
                                    <a href="javascript:;" data-toggle="dropdown"><img src="<?php echo e(asset('adminpanel/images/icon.png')); ?>"></a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="<?php echo e(url('/adminpanel/edituser/'.$d->id)); ?>"><span><i class="fas fa-edit"></i></span>Edit</a>
                                        <a class="dropdown-item" href="javascript:void(0)" onclick="confirmDelete('User', '<?php echo e(url('/adminpanel/deleteuser/'.$d->id)); ?>')"><span><i class="fas fa-trash-alt"></i></span>Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="listing-page-main-bottom">
                <div class="listing-page-main-bottom-left">
                    <?php echo e($data->render()); ?>

                </div>
                <div class="listing-page-main-bottom-right">
                    <div class="listing-page-main-bottom-right-drop-down">
                        <!-- <select class="classic arrow">
                            <option value="1">10</option>
                            <option value="1">10</option>
                            <option value="1">10</option>
                            <option value="1">10</option>
                        </select> -->
                    </div>
                    <div class="listing-page-main-bottom-right-cnt">
                        <p>Showing <?php echo e($data->firstItem()); ?> - <?php echo e($data->lastItem()); ?> of <?php echo e($data->total()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\Jannet new\resources\views/adminpanel/manageuser.blade.php ENDPATH**/ ?>