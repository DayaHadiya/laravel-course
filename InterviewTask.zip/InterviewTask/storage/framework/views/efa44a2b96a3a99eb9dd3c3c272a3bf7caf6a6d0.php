
<?php 
    $title = "Home | ".config('global.sitetitle');  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

	<?php
        $label = "Create";

        $username = "";
        $image = "";
        $email = "";
        $password = "";
        $phone = "";
        $id = "";
        $isError = false;

        $formRoute = 'adminpanel.user.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'adminpanel.user.update';
            }
            //$profile_image = $data['input']['profile_image'];
            $username = $data['input']['username'];
            $email = $data['input']['email'];
            $phone = $data['input']['phone'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $image = $data['input'][0]->image;
                $username = $data['input'][0]->username;
                $email = $data['input'][0]->email;
                $phone = $data['input'][0]->phone;
                $id = $data['input'][0]->id;
                           
                if($image!="" && $image!=null)
                {
                    if(file_exists(public_path()."/uploads/User_images/".$image))
                    {
                        $clogo = asset('/uploads/User_images/'.$image);
                    }
                }
                $formRoute = 'adminpanel.user.update';
            }
        }
        ?>
            <div class="top-dashboard-title">
                <div class="d-code-main">
                    <div class="d-title">
                        <h4><strong><?php echo e($label); ?> User</strong><span>|</span>Enter User details and submit </h4>
                    </div>
                </div>
            </div>

            <div class="dashboard-content-main add-user-main">
            <div class="add-user-one-main-content">
                <?php if($errors->any()): ?>
                    <div class="error-message-box">                    
                        <p><?php echo e($errors->first()); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($isError): ?>
                    <div class="error-message-box">
                        <?php foreach($data['error']->all() as $error) {
                            echo "<p>". $error . "</p>";
                        } ?>
                    </div>
                <?php endif; ?>
                <?php echo e(Form::open(array('route' => $formRoute, 'method' => 'post', 'enctype' => 'multipart/form-data'))); ?>

                    <?php echo e(Form::hidden('id', $id)); ?>

                    <div class="user-pro-detail-main-content">
                        <div class="user-pro-detail-sub-content">
                            <div class="user-pro-detail-main-content-title">
                                <h1>User management:</h1>
                            </div>
                            <div class="user-pro-detail-content">
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Profile Image</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <div class="user-img-main" style="display: flex; flex-direction: row; align-items: center; justify-content: center;">
                                            <img src="<?php echo e($clogo); ?>" id="logoimg" style="max-width: 100%; max-height: 100%; width: auto; height: auto;">
                                            <div class="button-wrapper">
                                                <span class="label">
                                                    <img src="<?php echo e(asset('adminpanel/images/pencil-edit-button.svg')); ?>">
                                                </span>
                                                <?php echo e(Form::file(
                                                    'image', 
                                                    [
                                                        'class' => 'upload-box',
                                                        'id' => 'image',
                                                        'placeholder' => 'Select Profile Image',
                                                        'onchange' => 'displaySingleImagePreview(this, "logoimg")'
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>User Name</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::text(
                                            'username', $username, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter UserName',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Email</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::email(
                                            'email', $email, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Email',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <?php
                                    if($label == "Create") 
                                    {
                                ?>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Password</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::password(
                                            'password',  
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Password',
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                 <?php } ?>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Phone No</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::number(
                                            'phone', $phone, 
                                            [
                                                'class' => 'form-control', 
                                                'placeholder' => 'Enter Phone Number',
                                                'required' => true
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                <?php
                                    if($data['type'] == "Edit") 
                                    {
                                ?>
                                <div class="user-pro-detail-content-dt-one">
                                    <div class="user-pro-detail-content-left">
                                        <label>Active</label>
                                    </div>
                                    <div class="user-pro-detail-content-right">
                                        <?php echo e(Form::checkbox(
                                            'active','',  
                                            [
                                                'class' => 'form-control', 
                                            ]
                                            )); ?>

                                    </div>
                                </div>
                                 <?php } ?>
                                            </div>
                                            <div class="next-step-btn-main">
                                                <?php echo e(Form::button(
                                                    'Save',
                                                    [
                                                        'class' => 'next-step',
                                                        'type' => 'submit'
                                                    ]
                                                    )); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pratapsingh\resources\views/adminpanel/adduser.blade.php ENDPATH**/ ?>