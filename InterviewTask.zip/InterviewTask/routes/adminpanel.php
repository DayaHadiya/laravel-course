<?php

// use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
 
Route::get('', function () {
    return redirect('/login');
})->name('index');
Route::get('/login', 'AuthController@login')->name('login');
Route::post('/login', 'AuthController@submitlogin')->name('submitlogin');
Route::get('/logout', 'AuthController@logout')->name('logout');

Route::group(['middleware' => 'auth:admin'], function(){
	//Dashboard
	Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

	//course
	Route::get('/managecourse', 'CourseController@manage')->name('course.manage');
	Route::get('/addcourse', 'CourseController@add')->name('course.add');
	Route::post('/addcourse', 'CourseController@save')->name('course.save');
	Route::get('/editcourse/{id}', 'CourseController@edit')->name('course.edit');
	Route::post('/editcourse', 'CourseController@update')->name('course.update');
	Route::get('/deletecourse/{id}', 'CourseController@delete')->name('course.delete');
	Route::get('/searchcourse', 'CourseController@search')->name('course.search');
	
	Route::get('/managearticle', 'ArticleController@manage')->name('article.manage');
	Route::get('/addarticle', 'ArticleController@add')->name('article.add');
	Route::post('/addarticle', 'ArticleController@save')->name('article.save');
	Route::get('/editarticle/{id}', 'ArticleController@edit')->name('article.edit');
	Route::post('/editarticle', 'ArticleController@update')->name('article.update');
	Route::get('/deletearticle/{id}', 'ArticleController@delete')->name('article.delete');
	Route::get('/searcharticle', 'ArticleController@search')->name('article.search');
	
});

?>